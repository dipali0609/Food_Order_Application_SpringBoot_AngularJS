package com.food.service;

import com.food.dao.Orderdata;

public interface OrderdataService {

	public Integer savedata();

}
