package com.food.service;

import com.food.dao.Payment;

public interface PaymentService {

	void savePayment(Payment payment);

	

}
