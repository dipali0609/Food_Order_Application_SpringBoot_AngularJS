package com.food.error;
public class GlobalExceptionHandling extends Exception {

	public GlobalExceptionHandling(String s) {
		super(s);
	}
}
